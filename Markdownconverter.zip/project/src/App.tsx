import React from 'react';
import { MarkdownEditor } from './components/MarkdownEditor';
import { MarkdownPreview } from './components/MarkdownPreview';
import { Toolbar } from './components/Toolbar';
import { useMarkdownState } from './hooks/useMarkdownState';
import { AlertCircle } from 'lucide-react';

function App() {
  const { 
    markdown, 
    setMarkdown, 
    parsedHtml, 
    showSuccessMessage, 
    successMessage 
  } = useMarkdownState();

  return (
    <div className="flex flex-col min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-800 text-white shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Markdown Preview Pro</h1>
            {showSuccessMessage && (
              <div className="fixed top-20 right-4 bg-emerald-500 text-white px-4 py-2 rounded shadow-lg flex items-center gap-2 animate-fade-in-out">
                <AlertCircle size={18} />
                <span>{successMessage}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6 h-full">
          {/* Editor Section */}
          <div className="w-full lg:w-1/2 flex flex-col">
            <h2 className="text-xl font-semibold mb-3 text-slate-700">Editor</h2>
            <div className="flex-grow">
              <MarkdownEditor markdown={markdown} onChange={setMarkdown} />
            </div>
          </div>

          {/* Preview Section */}
          <div className="w-full lg:w-1/2 flex flex-col">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-xl font-semibold text-slate-700">Preview</h2>
              <Toolbar html={parsedHtml} markdown={markdown} />
            </div>
            <div className="flex-grow bg-white border border-slate-200 rounded-md shadow-sm p-6 overflow-auto">
              <MarkdownPreview html={parsedHtml} />
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-4">
        <div className="container mx-auto px-4 text-center text-slate-300 text-sm">
          <p>© {new Date().getFullYear()} Markdown Preview Pro. Edit your Markdown and see the magic happen.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;