import React from 'react';
import 'github-markdown-css/github-markdown-light.css';
import 'highlight.js/styles/github.css';

interface MarkdownPreviewProps {
  html: string;
}

export const MarkdownPreview: React.FC<MarkdownPreviewProps> = ({ html }) => {
  return (
    <div 
      className="markdown-body w-full"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};