import React from 'react';
import { Copy, Download, FileText } from 'lucide-react';
import { useExportFunctions } from '../hooks/useExportFunctions';

interface ToolbarProps {
  html: string;
  markdown: string;
}

export const Toolbar: React.FC<ToolbarProps> = ({ html, markdown }) => {
  const { copyToClipboard, downloadAsPdf, downloadAsWord } = useExportFunctions(html, markdown);

  return (
    <div className="flex items-center space-x-2">
      <button
        className="toolbar-button bg-sky-500 hover:bg-sky-600 text-white"
        onClick={copyToClipboard}
        title="Copy preview content"
        aria-label="Copy preview content"
      >
        <Copy size={16} />
        <span className="hidden sm:inline">Copy</span>
      </button>

      <button
        className="toolbar-button bg-emerald-500 hover:bg-emerald-600 text-white"
        onClick={downloadAsPdf}
        title="Download as PDF"
        aria-label="Download as PDF"
      >
        <Download size={16} />
        <span className="hidden sm:inline">PDF</span>
      </button>

      <button
        className="toolbar-button bg-indigo-500 hover:bg-indigo-600 text-white"
        onClick={downloadAsWord}
        title="Download as Word"
        aria-label="Download as Word"
      >
        <FileText size={16} />
        <span className="hidden sm:inline">Word</span>
      </button>
    </div>
  );
};