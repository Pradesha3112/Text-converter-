import React from 'react';

interface MarkdownEditorProps {
  markdown: string;
  onChange: (value: string) => void;
}

export const MarkdownEditor: React.FC<MarkdownEditorProps> = ({ markdown, onChange }) => {
  return (
    <div className="relative h-full w-full">
      <textarea
        className="w-full h-full min-h-[400px] p-4 font-mono text-slate-800 bg-white border border-slate-200 rounded-md shadow-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
        value={markdown}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Type your markdown here..."
        spellCheck="false"
        aria-label="Markdown editor"
      />
    </div>
  );
};