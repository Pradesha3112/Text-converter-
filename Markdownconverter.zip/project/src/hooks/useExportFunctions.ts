import { useState, useCallback } from 'react';
import { jsPDF } from 'jspdf';
import { saveAs } from 'file-saver';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { marked } from 'marked';
import DOMPurify from 'dompurify';

export function useExportFunctions(html: string, markdown: string) {
  const [, setIsCopied] = useState(false);

  // Copy preview HTML to clipboard
  const copyToClipboard = useCallback(async () => {
    try {
      // Create a temporary element to hold the HTML content
      const tempElement = document.createElement('div');
      tempElement.innerHTML = html;
      
      // Get the text content
      const textContent = tempElement.textContent || '';
      
      // Copy to clipboard using the Clipboard API
      await navigator.clipboard.writeText(textContent);
      
      // Update state and show success message
      setIsCopied(true);
      
      // Display success message using a custom event
      window.dispatchEvent(new CustomEvent('showSuccessMessage', { 
        detail: { message: 'Preview content copied to clipboard!' } 
      }));
      
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
      window.dispatchEvent(new CustomEvent('showSuccessMessage', { 
        detail: { message: 'Failed to copy content!' } 
      }));
    }
  }, [html]);

  // Download as PDF
  const downloadAsPdf = useCallback(() => {
    try {
      // Create a temporary div with the HTML content
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = html;
      tempDiv.className = 'markdown-body';
      tempDiv.style.padding = '20px';
      document.body.appendChild(tempDiv);

      // Create PDF
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // Add content to PDF
      pdf.html(tempDiv, {
        callback: function(pdf) {
          pdf.save('markdown-preview.pdf');
          
          // Clean up
          document.body.removeChild(tempDiv);
          
          // Show success message
          window.dispatchEvent(new CustomEvent('showSuccessMessage', { 
            detail: { message: 'PDF downloaded successfully!' } 
          }));
        },
        x: 10,
        y: 10,
        width: 190,
        windowWidth: 1200
      });
    } catch (err) {
      console.error('Failed to download PDF:', err);
      window.dispatchEvent(new CustomEvent('showSuccessMessage', { 
        detail: { message: 'Failed to download PDF!' } 
      }));
    }
  }, [html]);

  const downloadAsWord = async () => {
    try {
      // Convert markdown to plain text (removing markdown syntax)
      const plainText = marked(markdown, { headerIds: false, mangle: false });
      const textContent = new DOMParser()
        .parseFromString(plainText, 'text/html')
        .documentElement.textContent || '';

      // Create a new document
      const doc = new Document({
        sections: [{
          properties: {},
          children: textContent.split('\n').map(line => 
            new Paragraph({
              children: [
                new TextRun({
                  text: line,
                  break: true
                })
              ]
            })
          )
        }]
      });

      // Generate and save the document
      const buffer = await Packer.toBlob(doc);
      saveAs(buffer, 'document.docx');
      
      // Show success message
      window.dispatchEvent(new CustomEvent('showSuccessMessage', { 
        detail: { message: 'Word document downloaded successfully!' } 
      }));
    } catch (err) {
      console.error('Failed to download Word document:', err);
      window.dispatchEvent(new CustomEvent('showSuccessMessage', { 
        detail: { message: 'Failed to download Word document!' } 
      }));
    }
  };

  return {
    copyToClipboard,
    downloadAsPdf,
    downloadAsWord
  };
}