import { useState, useEffect } from 'react';
import { marked } from 'marked';
import DOMPurify from 'dompurify';
import hljs from 'highlight.js';

// Configure marked with highlight.js for code highlighting
marked.setOptions({
  highlight: function(code, lang) {
    if (lang && hljs.getLanguage(lang)) {
      try {
        return hljs.highlight(code, { language: lang }).value;
      } catch (err) {
        console.error(err);
      }
    }
    return hljs.highlightAuto(code).value;
  },
  gfm: true,
  breaks: true,
});

// Sample markdown to start with
const DEFAULT_MARKDOWN = `# Welcome to Markdown Preview Pro

## Features

- **Real-time Preview**: See your changes instantly
- **GitHub Style Rendering**: Looks just like GitHub
- **Download Options**: Save as PDF or Word
- **Copy to Clipboard**: One-click copy of HTML

## Code Example

\`\`\`javascript
function greet(name) {
  return \`Hello, \${name}!\`;
}

console.log(greet('World'));
\`\`\`

## Table Example

| Feature | Description |
|---------|-------------|
| Markdown | Write in markdown |
| Preview | See rendered HTML |
| Export | Download as PDF/DOCX |
| Copy | Copy to clipboard |

> Try editing this markdown to see the preview update in real-time!
`;

export function useMarkdownState() {
  const [markdown, setMarkdown] = useState(DEFAULT_MARKDOWN);
  const [parsedHtml, setParsedHtml] = useState('');
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Parse markdown to HTML
  useEffect(() => {
    try {
      // Convert markdown to HTML and sanitize
      const rawHtml = marked.parse(markdown);
      const cleanHtml = DOMPurify.sanitize(rawHtml);
      setParsedHtml(cleanHtml);
    } catch (err) {
      console.error('Error parsing markdown:', err);
      setParsedHtml('<p>Error parsing markdown</p>');
    }
  }, [markdown]);

  // Show a success message
  const displaySuccessMessage = (message: string) => {
    setSuccessMessage(message);
    setShowSuccessMessage(true);
    
    // Hide the message after 3 seconds
    setTimeout(() => {
      setShowSuccessMessage(false);
    }, 3000);
  };

  return {
    markdown,
    setMarkdown,
    parsedHtml,
    showSuccessMessage,
    successMessage,
    displaySuccessMessage
  };
}