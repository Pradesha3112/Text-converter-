import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Create root and render App
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Add event listener for success messages
window.addEventListener('showSuccessMessage', (event: Event) => {
  const customEvent = event as CustomEvent<{ message: string }>;
  const appElement = document.getElementById('root');
  
  if (appElement && customEvent.detail && customEvent.detail.message) {
    // Dispatch a custom event that the App component can listen for
    const msgEvent = new CustomEvent('displayMessage', { 
      detail: { message: customEvent.detail.message } 
    });
    appElement.dispatchEvent(msgEvent);
  }
});